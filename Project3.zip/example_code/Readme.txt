Name: Xingsheng Zhao
NetID: 1001591499

-|code
--|ave # a MapReduce example to calculate average number
--|intsum # my MapReduce & Spark code written in python
--|wordcount # wordcount example in python

-|Proj3-Report.docx # Project3 report

-|Proj3-Peport.html # Project3 report in webpage form. Since some of the pictures are gif, 
		    # please open this file to see my report.

